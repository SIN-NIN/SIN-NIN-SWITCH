ChoiDujour 1.1.0 (21.07.2018)
Converts Nintendo Switch firmware update packages to installable images/files that can be transferred to the device itself.

Usage
 ChoiDujour.exe --help for a detailed Usage description page.
 Generally you can just drop the desired source firmware update package onto the exe as well, it will output NX-X.X.X folder on success.

For updates check https://switchtools.sshnuke.net
Source code available at https://github.com/rajkosto/ChoiDujour

**I am not responsible for anything, including dead switches, blown up PCs, loss of life, or total nuclear annihilation.**
