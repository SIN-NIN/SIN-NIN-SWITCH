local_wireless_tools
=====

![License](https://img.shields.io/badge/License-GPLv3-blue.svg)

Tools for Gen VII local wireless data.

**Licensing:**

This software is licensed under the terms of the GPLv3.  
You can find a copy of the license in the LICENSE file.
