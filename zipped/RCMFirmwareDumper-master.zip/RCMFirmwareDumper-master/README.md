# RCMFirmwareDumper
A simple rcm app that dumps the firmware nca files from sysmmc
