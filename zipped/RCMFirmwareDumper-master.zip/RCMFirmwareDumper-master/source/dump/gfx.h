#pragma once
#include "main.h"

int makemenu(menu_item menu[], int menuamount);
int message(char* message, u32 color);
void clearscreen();