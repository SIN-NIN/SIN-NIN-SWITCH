gptrestore v1 (16.05.2018)
Restores the original Nintendo Switch GPT to your eMMC if you somehow messed it up ;)

Usage
 Send the gptrestore.bin to your Switch running in RCM mode via a fusee-launcher (sudo ./fusee-launcher.py gptrestore.bin or just drag and drop it onto TegraRcmSmash.exe on Windows)
 Follow the on-screen prompts.


For updates check https://switchtools.sshnuke.net
Source code available at https://github.com/rajkosto/gptrestore

**I am not responsible for anything, including dead switches, loss of life, or total nuclear annihilation.**
