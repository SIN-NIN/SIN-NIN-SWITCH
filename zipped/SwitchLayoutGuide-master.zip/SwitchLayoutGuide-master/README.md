# SwitchLayoutGuide

Simple guide to help you make customised layouts like this one (theme not included)

[Get started in the Wiki!](https://github.com/suchmememanyskill/SwitchLayoutGuide/wiki)


Example on what you can do:
![thing](https://cdn.discordapp.com/attachments/470963123679920148/499658145740881922/unknown.png)
