# RandomSwitchThemeInstaller
A homebrew app to randomly install .szs theme files (atmosphere only)


### Install instructions:
Place the .nro file in the switch folder on your sd card, then make a folder called `hbshuffle` inside the themes folder. inside the hbshuffle folder make folders with incrumenting numbers (so you start with a folder called 1, then make another one called 2, and so on), and place your szs files inside of these folders.
