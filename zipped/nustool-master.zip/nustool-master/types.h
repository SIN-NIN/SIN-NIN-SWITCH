#ifndef NUSTOOL_TYPES_H
#define NUSTOOL_TYPES_H

#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stddef.h>

typedef uint8_t byte;

#ifndef __STDC_LIB_EXT1__
typedef int errno_t;
#endif

#endif

