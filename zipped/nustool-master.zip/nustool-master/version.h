#ifndef NUSTOOL_VERSION_H
#define NUSTOOL_VERSION_H

#define NUSTOOL_VERSION	"1.1"

#endif

