romdump v1 (20.05.2018)
Dumps the RAW FUSE, KFUSE and BOOTROM bytes to your microSD/HOST PC via USB/console screen

Usage
 Send the romdump.bin to your Switch running in RCM mode via a fusee-launcher (sudo ./fusee-launcher.py romdump.bin or just drag and drop it onto TegraRcmSmash.exe on Windows)
 Read the screen for warnings/errors (fuse bytes will also be printed here, however its much better to read them out from the microSD or via USB with TegraRcmSmash.exe -r)


For updates check https://switchtools.sshnuke.net
Source code available at https://github.com/rajkosto/romdump

**I am not responsible for anything, including dead switches, loss of life, or total nuclear annihilation.**
